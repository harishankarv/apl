import java.util.*;

public class TFFrequencies implements TFFrequenciesInterface {

	@Override
	public List<Map.Entry<String, Integer>> top25(List<String> words) {
		return this.sortHashMap(buildTermFrequencyMap(words));
	}

	// build a term frequency map from a list of words
	private static HashMap<String, Integer> buildTermFrequencyMap(List<String> fileWords) {
		HashMap<String, Integer> tfMap = new LinkedHashMap<String, Integer>();
		for(String w: fileWords) {
			int c = tfMap.containsKey(w) ? tfMap.get(w) : 0;
			tfMap.put(w, c + 1);
		}
		return tfMap;
	}
	

	private ArrayList<Map.Entry<String, Integer>> sortHashMap(Map<String, Integer> tfMap) {

		LinkedHashMap<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
		ArrayList<Map.Entry<String, Integer>> mapAsArray = new ArrayList<>();

		for (Map.Entry<String, Integer> e : tfMap.entrySet()) {
			mapAsArray.add(e);
		}

		Comparator<Map.Entry<String, Integer>> myComparator = new Comparator<Map.Entry<String, Integer>>() {
			@Override
			public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
				Integer i = a.getValue();
				Integer j = b.getValue();
				return j.compareTo(i);
			}
		};

		Collections.sort(mapAsArray, myComparator);
		return mapAsArray;
	}

}