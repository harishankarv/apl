import java.io.*;
import java.util.*;

public class TFWords implements TFWordsInterface{

	@Override
	public List<String> extractWords(String pathToFile) {
		return this.removeStopWords(fileToWordList(normalizeFile(readFile(pathToFile))));
	}

	// read entire file into string (StringBuilder) and return
	private StringBuilder readFile(String filePath) {
		StringBuilder fileString = null;
		try (Scanner sc = new Scanner(new File(filePath))){
			 fileString = new StringBuilder(sc.useDelimiter("\\Z").next());
			return fileString;
		} catch (FileNotFoundException e) {
			System.err.println(e.toString());
			System.exit(-1);
		}
		return fileString;	
	}
	
	// remove non-alphanumeric characters from string (StringBuilder),
	// convert all characters to lowercase and return a string
	private String normalizeFile(StringBuilder fileString) {
		for (int i = 0; i < fileString.length(); i++) {
			   char c = fileString.charAt(i);
			   if (!Character.isLetterOrDigit(c))
				   fileString.setCharAt(i,  ' ');
			   else
				   fileString.setCharAt(i, Character.toLowerCase(c));
			}
		return fileString.toString();
	}
	
	// convert the a string into a list of words and return list 
	private List<String> fileToWordList(String fileString) {
		ArrayList<String> fileWords = new ArrayList<String>();
		for(String w : fileString.split("[^a-zA-Z0-9]+"))
			fileWords.add(w);
		return fileWords;
	}
	
	// remove stop words from a list of words  
	// using the stop words from stop_words.txt
	private List<String> removeStopWords(List<String> fileWords) {
		HashSet<String> stopWordsSet = new HashSet<String>();
		try (Scanner sc = new Scanner(new File("../stop_words.txt"))) {
			for (String s : sc.nextLine().split(",")) {
				stopWordsSet.add(s);
			}
		} catch (FileNotFoundException e) {
			System.err.println(e.toString());
			System.exit(-1);
		}
		fileWords.removeIf(w -> stopWordsSet.contains(w) || w.length() < 2);
		return fileWords;
	}
	
}
