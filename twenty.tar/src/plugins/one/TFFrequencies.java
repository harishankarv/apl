import java.util.*;

public class TFFrequencies implements TFFrequenciesInterface {

	@Override
	public List<Map.Entry<String, Integer>> top25(List<String> words) {

		HashMap<String, Integer>tfMap = new HashMap<String, Integer>();
		ArrayList<Map.Entry<String, Integer>> tfMapAsArray = new ArrayList<>();
	    
	 	for (String w: words){
			int c = tfMap.containsKey(w) ? tfMap.get(w) : 0;
			tfMap.put(w, c + 1);
	    }

		for (Map.Entry<String, Integer> e : tfMap.entrySet()) {
			tfMapAsArray.add(e);
		}

		Comparator<Map.Entry<String, Integer>> comp = new Comparator<Map.Entry<String, Integer>>() {
			@Override
			public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
				Integer i = a.getValue();
				Integer j = b.getValue();
				return j.compareTo(i);
			}
		};

		Collections.sort(tfMapAsArray, comp);
		return tfMapAsArray;
	}

}