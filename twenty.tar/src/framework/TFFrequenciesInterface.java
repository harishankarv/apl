import java.util.List;
import java.util.Map;

public interface TFFrequenciesInterface {
	
	List<Map.Entry<String, Integer>> top25(List<String> words);
	
}
