import java.io.*;
import java.util.*;

public class TFWords implements TFWordsInterface{

	@Override
	public List<String> extractWords(String pathToFile) {
		
		HashSet<String> stopWords = new HashSet<String>();
		ArrayList<String> fileWords = new ArrayList<String>();

		try (Scanner sc = new Scanner(new File("../stop_words.txt"))){
			for (String s : sc.nextLine().split(",")) {
					stopWords.add(s);
			}
		}  catch (FileNotFoundException e) {
			System.err.println(e.toString());
			System.exit(-1);
		}
        
        // Add single-letter words
        for (char c = 'a'; c <= 'z'; c++) {
            stopWords.add("" + c);
        }

		try (Scanner sc = new Scanner(new File(pathToFile))){
			StringBuilder fileString = new StringBuilder(sc.useDelimiter("\\Z").next());
			for (int i = 0; i < fileString.length(); i++) {
				   char c = fileString.charAt(i);
				   if (!Character.isLetterOrDigit(c))
					   fileString.setCharAt(i,  ' ');
				   else
					   fileString.setCharAt(i, Character.toLowerCase(c));
			}
			for(String w : fileString.toString().split("[^a-zA-Z0-9]+")){
			if(!stopWords.contains(w))
				fileWords.add(w);
			}
		}  catch (FileNotFoundException e) {
			System.err.println(e.toString());
			System.exit(-1);
		}
        
		return fileWords;
	}
}
