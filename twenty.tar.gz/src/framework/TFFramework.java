import java.util.*;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

class TFFramework {

  public static void main(String[] args) throws Exception{

    // read properties
    Properties p = new  Properties(); 
    FileReader fr;
    fr = new FileReader("config.properties"); 
    p.load(fr);  
        
    URL wordsClassURL = null;
    URL frequenciesClassURL = null;

    // Find classses in the given jar file
    File wordsFile = new File(p.getProperty("words"));
    File frequenciesFile = new File(p.getProperty("frequencies"));
    wordsClassURL = wordsFile.toURI().toURL();
    frequenciesClassURL = frequenciesFile.toURI().toURL();

    URL[] classUrls = {wordsClassURL, frequenciesClassURL};
    URLClassLoader cloader = new URLClassLoader(classUrls);
    
    Class wordsClass = null;
    Class frequenciesClass = null;
    wordsClass = cloader.loadClass("TFWords");
    frequenciesClass = cloader.loadClass("TFFrequencies");

    if (wordsClass != null && frequenciesClass !=null) {
  		TFWordsInterface tfw = (TFWordsInterface)wordsClass.newInstance();
      TFFrequenciesInterface tff = (TFFrequenciesInterface)frequenciesClass.newInstance();
      List<String> words  = tfw.extractWords(args[0]);
      List<Map.Entry<String, Integer>> tfMapAsArray = tff.top25(words);
      int c = 0;
      for (Map.Entry<String, Integer> e : tfMapAsArray) {
        if (c == 25)
          break;
        System.out.println(e.getKey() + "  -  " + e.getValue());
        c++;
      }
    }
  }
}