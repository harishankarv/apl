import java.util.List;

public interface TFWordsInterface {
	
	List<String> extractWords(String pathToFile);
	
}
